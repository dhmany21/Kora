
document.addEventListener("DOMContentLoaded", () => {
    const counters = document.querySelectorAll(".stat-number");
    counters.forEach(counter => {
        counter.innerText = "0";
        const update = () => {
            const target = +counter.getAttribute("data-target");
            const current = +counter.innerText;
            const step = Math.ceil(target / 100);
            if (current < target) {
                counter.innerText = Math.min(current + step, target);
                setTimeout(update, 30);
            }
        };
        update();
    });
});
